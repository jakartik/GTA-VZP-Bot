import os
import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
DISCORD_CHANNEL_ID = int(os.getenv("DISCORD_CHANNEL_ID"))
DISCORD_ROLE_ID = int(os.getenv("DISCORD_ROLE_ID"))

intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
intents.reactions = True
intents.guilds = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)
reaction_users = set()

@bot.event
async def on_ready():
    print(f"Discord Bot connected as {bot.user}")

@bot.command()
async def vzp(ctx, *, text):
    channel = bot.get_channel(DISCORD_CHANNEL_ID)
    role = ctx.guild.get_role(DISCORD_ROLE_ID)
    msg = await channel.send(f"{role.mention}
📢 **{text}**

Нажмите ✅ если идёте.")
    await msg.add_reaction("✅")

    def check(reaction, user):
        return str(reaction.emoji) == "✅" and reaction.message.id == msg.id and not user.bot

    @bot.event
    async def on_reaction_add(reaction, user):
        if reaction.message.id == msg.id and str(reaction.emoji) == "✅":
            reaction_users.add(user.name)

    @bot.command()
    async def список(ctx):
        if reaction_users:
            await ctx.send("📝 Участники:
" + "
".join(reaction_users))
        else:
            await ctx.send("❌ Никто не откликнулся.")

def run_discord_bot():
    bot.run(DISCORD_TOKEN)
