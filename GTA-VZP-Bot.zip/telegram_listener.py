from telethon import TelegramClient, events
import os
from dotenv import load_dotenv
import requests

load_dotenv()

API_ID = int(os.getenv("TG_API_ID"))
API_HASH = os.getenv("TG_API_HASH")
SESSION_NAME = "tg_session"

DISCORD_WEBHOOK = os.getenv("DISCORD_WEBHOOK")

client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

@client.on(events.NewMessage(incoming=True))
async def handler(event):
    message = event.message.message
    if "забила" in message and "войну за" in message:
        data = {
            "content": f"📢 Обнаружена ВЗП в Telegram!

{message}"
        }
        requests.post(DISCORD_WEBHOOK, json=data)

def start_telegram_listener():
    client.start()
    print("Telegram listener started")
    client.run_until_disconnected()
