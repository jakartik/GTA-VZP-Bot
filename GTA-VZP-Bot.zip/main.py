from discord_bot import run_discord_bot
from telegram_listener import start_telegram_listener
import threading

if __name__ == "__main__":
    threading.Thread(target=start_telegram_listener).start()
    run_discord_bot()
